#include <stdio.h>

int main() {
    char nome[100];
    int horas;
    int dependentes;
    double salarioBruto;
    double desconto;
    double salarioLiquido;
    
    printf("Digite o nome do funcionário: ");
    fgets(nome, 100, stdin);
    printf("Digite o número de horas trabalhadas: ");
    scanf("%d", &horas);
    printf("Digite o número de dependentes: ");
    scanf("%d", &dependentes);
    
    salarioBruto = (horas * 3.00) + (dependentes * 100.00);
    desconto = salarioBruto * 0.135;
    salarioLiquido = salarioBruto - desconto;
    
    printf("\nNome: %s", nome);
    printf("Salário Líquido: R$ %.2f\n", salarioLiquido);
    
    return 0;
}
