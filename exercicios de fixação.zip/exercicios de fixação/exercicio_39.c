#include <stdio.h>

int main() {
    double custoFabrica;
    double custoDistribuidor;
    double custoImpostos;
    double custoConsumidor;
    
    printf("Digite o custo de fábrica do carro: R$ ");
    scanf("%lf", &custoFabrica);
    
    custoDistribuidor = custoFabrica * 0.28;
    custoImpostos = custoFabrica * 0.45;
    custoConsumidor = custoFabrica + custoDistribuidor + custoImpostos;
    
    printf("Custo do carro ao consumidor: R$ %.2f\n", custoConsumidor);
    
    return 0;
}
