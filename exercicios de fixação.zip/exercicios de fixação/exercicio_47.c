#include <stdio.h>

int quantidadeProdutos;
double salarioFixo;
double comissao = 0;
double salarioTotal;
double totalSalarios = 0;
double mediaSalarios;
double maiorSalarioFixo = 0;
int funcionarios = 1200;

int main() {
    
    for (int i = 0; i < funcionarios; i++) {
        printf("Funcionário %d\n", i + 1);
        printf("Digite a quantidade de produtos vendidos: ");
        scanf("%d", &quantidadeProdutos);
        printf("Digite o salário fixo: R$ ");
        scanf("%lf", &salarioFixo);
        
        if (quantidadeProdutos <= 5) {
            comissao = quantidadeProdutos * 1.50;
        } else if (quantidadeProdutos >= 6 && quantidadeProdutos <= 50) {
            comissao = quantidadeProdutos * 2.00;
        } else {
            comissao = quantidadeProdutos * 2.50;
        }
        
        salarioTotal = salarioFixo + comissao;
        printf("a) Salário: R$ %.2f\n\n", salarioTotal);
        
        totalSalarios += salarioTotal;
        
        if (salarioFixo > maiorSalarioFixo) {
            maiorSalarioFixo = salarioFixo;
        }
    }
    
    mediaSalarios = totalSalarios / funcionarios;
    
    printf("b) Média dos salários: R$ %.2f\n", mediaSalarios);
    printf("c) Maior salário fixo: R$ %.2f\n", maiorSalarioFixo);
    
    return 0;
}
