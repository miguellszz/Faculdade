#include <stdio.h>

int main() {
    double celsius;
    double fahrenheit;
    
    printf("Digite a temperatura em Celsius: ");
    scanf("%lf", &celsius);
    
    fahrenheit = (9.0 / 5.0) * celsius + 32;
    
    printf("%.2f°C = %.2f°F\n", celsius, fahrenheit);
    
    return 0;
}
