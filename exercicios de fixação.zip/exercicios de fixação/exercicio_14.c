#include <stdio.h>
#include <stdlib.h>

int numero;

int main() {
    printf("Digite um numero: ");
    scanf("%d", &numero);
    printf("O numero digitado foi: %d", numero);

}