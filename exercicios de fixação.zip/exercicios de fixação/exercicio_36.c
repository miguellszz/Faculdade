#include <stdio.h>
#include <math.h>

int main() {
    double potencia;
    double largura;
    double comprimento;
    double area;
    int lampadasNecessarias;
    double potenciaTotal;
    
    printf("Digite a potência da lâmpada (watts): ");
    scanf("%lf", &potencia);
    printf("Digite a largura do cômodo (m): ");
    scanf("%lf", &largura);
    printf("Digite o comprimento do cômodo (m): ");
    scanf("%lf", &comprimento);
    
    area = largura * comprimento;
    potenciaTotal = area * 18;
    lampadasNecessarias = (int)ceil(potenciaTotal / potencia);
    
    printf("Número de lâmpadas necessárias: %d\n", lampadasNecessarias);
    
    return 0;
}
