#include <stdio.h>
#include <stdlib.h>

int numero1 = 0, numero2 = 0,soma;

int main() {
    printf("Digire seu primeiro numero ");
    scanf("%d", &numero1);

    printf("Digite seu segundo numero: ");
    scanf("%d", &numero2);

    soma = numero1 + numero2;
    printf("A soma dos numeros é: %d", soma);
}