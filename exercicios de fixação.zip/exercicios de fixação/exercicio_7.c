#include <stdio.h>

int numero, multiplicacao;

int main() {
    printf("Digite o numero que voce deseja o quadrado: ");
    scanf("%d", &numero);

    multiplicacao = numero * numero;
    printf("O Quadrado de: %d é: %d", numero, multiplicacao);

    return 0;

}