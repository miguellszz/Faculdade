#include <stdio.h>

int numero;

int main() {
    printf("Digite um numero: ");
    scanf("%d", &numero);

    for (int i = 1; i <=5 ; i++){
        printf("Os sucessores sao: %d\n", numero + i);
        
    }

}

