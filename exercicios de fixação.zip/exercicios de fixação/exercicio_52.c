#include <stdio.h>

int main() {
    int idade;
    double salarioBruto;
    int acidente;
    double salarioLiquido;
    double totalSalariosLiquidos = 0;
    double somaidadeAcidentados = 0;
    int quantidadeAcidentados = 0;
    int totalPessoas = 0;
    double mediaIdadeAcidentados;
    
    while (1) {
        printf("Digite o salário bruto: R$ ");
        scanf("%lf", &salarioBruto);
        
        if (salarioBruto < 0) break;
        
        printf("Digite a idade: ");
        scanf("%d", &idade);
        printf("Sofreu acidente de trabalho? (1-Sim / 0-Não): ");
        scanf("%d", &acidente);
        
        totalPessoas++;
        
        if (salarioBruto > 1500) {
            salarioLiquido = salarioBruto - (salarioBruto * 0.10);
        } else {
            salarioLiquido = salarioBruto;
        }
        
        totalSalariosLiquidos += salarioLiquido;
        
        if (acidente == 1) {
            quantidadeAcidentados++;
            somaidadeAcidentados += idade;
        }
    }
    
    if (quantidadeAcidentados > 0) {
        mediaIdadeAcidentados = somaidadeAcidentados / quantidadeAcidentados;
        printf("\na) Média de idade das pessoas que sofreram acidente: %.2f anos\n", mediaIdadeAcidentados);
    }
    
    printf("b) Total de salários líquidos pagos: R$ %.2f\n", totalSalariosLiquidos);
    
    return 0;
}
