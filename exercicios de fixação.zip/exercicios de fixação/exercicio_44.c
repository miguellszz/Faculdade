#include <stdio.h>

int main() {
    printf("Celsius para Fahrenheit\n");
    printf("-----------------\n");
    
    for (int celsius = 0; celsius <= 50; celsius += 10) {
        double fahrenheit = (9.0 / 5.0) * celsius + 32;
        printf("%d %.2f\n", celsius, fahrenheit);
    }
    
    return 0;
}
