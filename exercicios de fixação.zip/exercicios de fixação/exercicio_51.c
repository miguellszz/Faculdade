#include <stdio.h>

int linhas, colunas;

int main() {
    
    printf("Digite o número de linhas: ");
    scanf("%d", &linhas);
    printf("Digite o número de colunas: ");
    scanf("%d", &colunas);
    
    if (linhas < 1) linhas = 1;
    if (linhas > 20) linhas = 20;
    if (colunas < 1) colunas = 1;
    if (colunas > 20) colunas = 20;
    
    for (int i = 0; i < linhas; i++) {
        for (int j = 0; j < colunas; j++) {
            printf("*");
        }
        printf("\n");
    }
    
    return 0;
}
