#include <stdio.h>

int numero;

int main() {
    printf("Digite um numero: ");
    scanf("%d", &numero);

    if (numero % 2 == 0) {
        printf("Os proximos numeros sao:");
        for (;numero<11 ; numero+=2) {
            printf("\n%d", numero);
        }
    }

}


