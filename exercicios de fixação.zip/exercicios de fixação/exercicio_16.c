#include <stdio.h>
#include <stdlib.h>

int idade1,idade2,idade3,media;

int main() {
    printf("Digite as idades em ordem, ex: 10 11 12: ");
    scanf("%d %d %d", &idade1,&idade2,&idade3);

    media = (idade1 + idade2 + idade3)/3;
    printf("a mediad a idade de voces é : %d", media);
}