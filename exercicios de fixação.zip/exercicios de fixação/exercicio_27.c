#include <stdio.h>

int main() {
    int N;
    
    while (1) {
        printf("Digite um número (0 para sair): ");
        scanf("%d", &N);
        
        if (N == 0) break;
        
        int soma = 0;
        int termo = 1;
        int contagem = 0;
        
        while (soma < N) {
            soma += termo;
            termo += 2;
            contagem++;
        }
        
        if (soma == N) {
            printf("Raiz quadrada de %d é %d (%d termos)\n", N, contagem, contagem);
        } else {
            printf("%d não é um quadrado perfeito\n", N);
        }
    }
    
    return 0;
}
