#include <stdio.h>

int main() {
    double fahrenheit;
    double celsius;
    
    printf("Digite a temperatura em Fahrenheit: ");
    scanf("%lf", &fahrenheit);
    
    celsius = (5.0 / 9.0) * (fahrenheit - 32);
    
    printf("%.2f°F = %.2f°C\n", fahrenheit, celsius);
    
    return 0;
}
