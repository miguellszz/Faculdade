#include <stdio.h>
#include <math.h>

int main() {
    double raio;
    double altura;
    double volume;
    
    printf("Digite o raio do cilindro (m): ");
    scanf("%lf", &raio);
    printf("Digite a altura do cilindro (m): ");
    scanf("%lf", &altura);
    
    volume = M_PI * raio * raio * altura;
    
    printf("Volume do cilindro: %.2f m³\n", volume);
    
    return 0;
}
