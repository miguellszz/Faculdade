#include <stdio.h>

int main() {
    double odometroInicial;
    double odometroFinal;
    double litrosGastos;
    double precoCombustivel;
    double kmRodado;
    double kmPorLitro;
    double custViagem;
    
    printf("Digite a quilometragem inicial: ");
    scanf("%lf", &odometroInicial);
    printf("Digite a quilometragem final: ");
    scanf("%lf", &odometroFinal);
    printf("Digite os litros de combustível gasto: ");
    scanf("%lf", &litrosGastos);
    printf("Digite o preço do combustível (R$/litro): ");
    scanf("%lf", &precoCombustivel);
    
    kmRodado = odometroFinal - odometroInicial;
    kmPorLitro = kmRodado / litrosGastos;
    custViagem = litrosGastos * precoCombustivel;
    
    printf("\na) Quilometragem rodada: %.2f km\n", kmRodado);
    printf("b) Quilômetros por litro: %.2f km/l\n", kmPorLitro);
    printf("c) Custo da viagem: R$ %.2f\n", custViagem);
    
    return 0;
}
