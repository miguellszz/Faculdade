#include <stdio.h>

int vezes;
int totalAlunos = 0;
int abaixo10 = 0;
int entre10e15 = 0;
int acima15 = 0;

double percentualAbaixo10;
double percentualEntre10e15;
double percentualAcima15;

int main() {

    
    while (1) {
        printf("Digite o número de vezes que usou o restaurante (negativo para sair): ");
        scanf("%d", &vezes);
        
        if (vezes < 0) break;
        
        totalAlunos++;
        
        if (vezes < 10) {
            abaixo10++;
        } else if (vezes >= 10 && vezes <= 15) {
            entre10e15++;
        } else {
            acima15++;
        }
    }
    
    if (totalAlunos > 0) {
        percentualAbaixo10 = (double)abaixo10 / totalAlunos * 100;
        percentualEntre10e15 = (double)entre10e15 / totalAlunos * 100;
        percentualAcima15 = (double)acima15 / totalAlunos * 100;
        
        printf("\na) Percentual que usou menos de 10 vezes: %.2f%%\n", percentualAbaixo10);
        printf("b) Percentual que usou entre 10 e 15 vezes: %.2f%%\n", percentualEntre10e15);
        printf("c) Percentual que usou acima de 15 vezes: %.2f%%\n", percentualAcima15);
        printf("d) Número de alunos entrevistados: %d\n", totalAlunos);
    }
    
    return 0;
}
