#include <stdio.h>

double areaTotal = 0;
int continuar = 1;

int main(){

    while (continuar == 1) {
        double largura, comprimento;

        printf("Digite a largura do cômodo (m): ");
        scanf("%lf", &largura);
        printf("Digite o comprimento do cômodo (m): ");
        scanf("%lf", &comprimento);

        areaTotal += largura * comprimento;

        printf("Deseja continuar? (1=sim, 0=não): ");
        scanf("%d", &continuar);
    }

    printf("Área total da residência: %.2f m²\n", areaTotal);

    return 0;
}