#include <stdio.h>

int main() {
    int sexo;
    double altura;
    double somaAlturasMulheres = 0;
    double somaAlturasTotais = 0;
    int qtdMulheres = 0;
    int qtdHomens = 0;
    int mulheresAbaixo165 = 0;
    int n = 50;
    
    for (int i = 0; i < n; i++) {
        printf("Pessoa %d - Digite a altura (m): ", i + 1);
        scanf("%lf", &altura);
        printf("Digite o sexo (0=masculino, 1=feminino): ");
        scanf("%d", &sexo);
        
        somaAlturasTotais += altura;
        
        if (sexo == 1) {
            qtdMulheres++;
            somaAlturasMulheres += altura;
            if (altura < 1.65) {
                mulheresAbaixo165++;
            }
        } else {
            qtdHomens++;
        }
    }
    
    double mediaAlturasMulheres = somaAlturasMulheres / qtdMulheres;
    double mediaAlturasTotais = somaAlturasTotais / n;
    double percentualHomens = (double)qtdHomens / n * 100;
    double percentualMulheresAbaixo165 = (double)mulheresAbaixo165 / qtdMulheres * 100;
    
    printf("\na) Média de altura das mulheres: %.2f m\n", mediaAlturasMulheres);
    printf("b) Média de altura da população: %.2f m\n", mediaAlturasTotais);
    printf("c) Percentual de homens: %.2f%%\n", percentualHomens);
    printf("d) Quantidade de mulheres: %d\n", qtdMulheres);
    printf("e) Percentual de mulheres abaixo de 1.65m: %.2f%%\n", percentualMulheresAbaixo165);
    
    return 0;
}
