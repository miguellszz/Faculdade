#include <stdio.h>

int main() {
    double soma = 0;

    for (int i = 1; i <= 50; i++) {
        soma += (double)(51 - i) / i;
    }

    printf("Somatório: %.2f\n", soma);

    return 0;
}