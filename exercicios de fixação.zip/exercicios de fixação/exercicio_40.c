#include <stdio.h>
#include <math.h>

int main() {
    int a, b, c;
    double r, s, d;
    
    printf("Digite o valor de A: ");
    scanf("%d", &a);
    printf("Digite o valor de B: ");
    scanf("%d", &b);
    printf("Digite o valor de C: ");
    scanf("%d", &c);
    
    r = pow(a + b, 2);
    s = pow(b + c, 2);
    d = (r + s) / 2;
    
    printf("D = %.2f\n", d);
    
    return 0;
}
