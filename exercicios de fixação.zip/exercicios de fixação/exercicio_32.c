#include <stdio.h>
#include <math.h>

int main() {
    double raio;
    double comprimento;
    
    printf("Digite o raio do círculo (m): ");
    scanf("%lf", &raio);
    
    comprimento = 2 * M_PI * raio;
    
    printf("Comprimento do círculo: %.2f m\n", comprimento);
    
    return 0;
}
