#include <stdio.h>

int main() {
    int dias;
    double diaria = 150.00;
    double desconto = 0;
    double valor = 0;
    double totalPago = 0;
    double mediaValores = 0;
    double mediadias = 0;
    double maiorConta = 0;
    int hospedes = 0;
    int hospedes20dias = 0;
    int somaHospedes20 = 0;
    
    while (1) {
        printf("Digite a quantidade de diárias (0 para sair): ");
        scanf("%d", &dias);
        
        if (dias == 0) break;
        
        hospedes++;
        mediadias += dias;
        
        if (dias > 20) {
            hospedes20dias++;
        }
        
        valor = dias * diaria;
        
        if (dias <= 5) {
            desconto = valor * 0.05;
        } else if (dias >= 6 && dias <= 10) {
            desconto = valor * 0.10;
        } else {
            desconto = valor * 0.15;
        }
        
        valor -= desconto;
        
        printf("Valor a pagar: R$ %.2f\n", valor);
        
        totalPago += valor;
        
        if (valor > maiorConta) {
            maiorConta = valor;
        }
    }
    
    if (hospedes > 0) {
        mediaValores = totalPago / hospedes;
        mediadias = mediadias / hospedes;
        
        printf("\na) Hóspedes com mais de 20 dias: %d\n", hospedes20dias);
        printf("b) Valores pagos pelos hóspedes foram impressos acima\n");
        printf("c) Média dos valores das contas: R$ %.2f\n", mediaValores);
        printf("d) Média de dias de permanência: %.2f\n", mediadias);
        printf("e) Maior conta paga: R$ %.2f\n", maiorConta);
    }
    
    return 0;
}
