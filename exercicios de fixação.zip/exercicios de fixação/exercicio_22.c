#include <stdio.h>
#include <stdlib.h>
#include <iso646.h>

int i ,numero,tabuada,opcao;

int main() {
    printf("Digite o numero que voce deseja obter a tabuada: ");
    scanf("%d", &numero);

    for (i = 0; i<=10 ; i++) {
        tabuada = i * numero;
        printf("\nA tabuade de %d é %d x %d = %d ", numero, numero, i, tabuada);
    }
    do {
        printf("\nVoce deseja saber a tabuada de outro valor? \n1 - S E 2 - N\n");
        scanf("%d", &opcao);
        if (opcao == 1) {
            printf("Digite o numero que voce deseja obter a tabuada: ");
            scanf("%d", &numero);
            for (i = 0; i<=10 ; i++) {
                tabuada = i * numero;
                printf("\nA tabuade de %d é %d x %d = %d ", numero, numero, i, tabuada);
            }
        }

    }while (opcao == 2);{
        return 0;
    }
}