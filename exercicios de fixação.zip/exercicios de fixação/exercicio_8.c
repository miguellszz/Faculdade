#include <stdio.h>
#include <math.h>
int numero1,numero2,elevado1,elevado2;

int main() {
    printf("Digite o primeiro numero: ");
    scanf("%d",&numero1);

    printf("Digite o segundo numero: ");
    scanf("%d", &numero2);

    elevado1 = pow(numero1, numero2);
    elevado2 = pow(numero2, numero1);

    printf("O resultado da primeira elevação é: %d\n", elevado1);
    printf("O resultado da segunda elevação é: %d\n", elevado2);

}