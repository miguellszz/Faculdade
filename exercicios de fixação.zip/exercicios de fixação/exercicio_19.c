#include <stdio.h>

int main() {
    int numero;
    int positivos = 0;

    for(int i = 1; i <= 5; i++) {
        printf("Digite um numero: ");
        scanf("%d", &numero);

        if(numero > 0) {
            positivos++;
        }
    }

    printf("Quantidade de numeros positivos: %d\n", positivos);

    return 0;
}
