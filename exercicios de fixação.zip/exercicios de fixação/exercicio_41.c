#include <stdio.h>

int main() {
    int numeroVendedor;
    char nomeVendedor[100];
    int carrosVendidos;
    double valorVendas;
    double salarioFixo;
    double valorPorCarro;
    double salarioTotal;
    double comissaoVendas;
    
    printf("Digite o número do vendedor: ");
    scanf("%d", &numeroVendedor);
    scanf("%*c");
    printf("Digite o nome do vendedor: ");
    fgets(nomeVendedor, 100, stdin);
    printf("Digite o número de carros vendidos: ");
    scanf("%d", &carrosVendidos);
    printf("Digite o valor total de vendas: R$ ");
    scanf("%lf", &valorVendas);
    printf("Digite o salário fixo: R$ ");
    scanf("%lf", &salarioFixo);
    printf("Digite o valor por carro vendido: R$ ");
    scanf("%lf", &valorPorCarro);
    
    comissaoVendas = valorVendas * 0.05;
    salarioTotal = salarioFixo + (carrosVendidos * valorPorCarro) + comissaoVendas;
    
    printf("\nCódigo: %d\n", numeroVendedor);
    printf("Nome: %s", nomeVendedor);
    printf("Salário Mensal: R$ %.2f\n", salarioTotal);
    
    return 0;
}
