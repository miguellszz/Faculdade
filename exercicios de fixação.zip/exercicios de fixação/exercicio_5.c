#include <stdio.h>
#include <stdlib.h>

int numero, sucessor;

int main() {
   printf("Digite um numero: ");
   scanf("%d", &numero);

   sucessor = numero + 1;
      printf("O sucessor de %d é: %d", numero, sucessor);
   }