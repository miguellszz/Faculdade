#include <stdio.h>

int main() {
    double razao;
    double primeiroTermo;
    double ultimoTermo;
    int numeroTermos;
    double soma;
    
    printf("Digite a razão da PA: ");
    scanf("%lf", &razao);
    printf("Digite o primeiro termo: ");
    scanf("%lf", &primeiroTermo);
    printf("Digite o último termo: ");
    scanf("%lf", &ultimoTermo);
    
    numeroTermos = (int)((ultimoTermo - primeiroTermo) / razao) + 1;
    soma = (numeroTermos * (primeiroTermo + ultimoTermo)) / 2;
    
    printf("Soma da PA: %.2f\n", soma);
    
    return 0;
}
