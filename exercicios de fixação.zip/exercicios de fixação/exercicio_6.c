#include <stdio.h>
#include <stdlib.h>
#include <math.h>

double raiz;
int numero = 25;

int main() {
    raiz = sqrt(numero);
    printf ("A raiz de %d é %.2f", numero,raiz);
}