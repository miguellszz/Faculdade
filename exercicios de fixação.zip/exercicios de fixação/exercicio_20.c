#include <stdio.h>

int numeros[10],numero;

int main() {
    for (int i = 0; i <=10; i++) {
        printf("Digite os numeros: ");
        scanf("%d", &numeros[i]);

        if (numeros[i] % 2 == 0) {
            printf("È par\n");
        } else {
            printf("È impar\n");
        }
    }
}

