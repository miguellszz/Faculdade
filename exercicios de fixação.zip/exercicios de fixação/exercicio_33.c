#include <stdio.h>
#include <math.h>

int main() {
    double raio;
    double area;
    
    printf("Digite o raio do círculo (m): ");
    scanf("%lf", &raio);
    
    area = M_PI * raio * raio;
    
    printf("Área do círculo: %.2f m²\n", area);
    
    return 0;
}
