#include <stdio.h>

int numero1,numero2;
float restoDiv;

int main() {
    printf("Digite o primeiro numero: ");
    scanf("%d",&numero1);

    printf("Digite o segundo numero: ");
    scanf("%d",&numero2);

    restoDiv = numero1 % numero2;
    printf("O resto de divisao é : %.2f", restoDiv);

}