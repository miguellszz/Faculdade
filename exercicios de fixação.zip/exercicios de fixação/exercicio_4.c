#include <stdio.h>
#include <stdlib.h>

int numero1 = 0;
int numero2 = 0;

int multi;

int main() {
    printf("Digite o primeiro numero: ");
    scanf("%d", &numero1);

    printf("Diigite o segundo numero: ");
    scanf("%d", &numero2);

    multi = numero1 * numero2;
    printf("O resultado da multiplicação é: %d ", multi);
}




