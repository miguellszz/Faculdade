#include <stdio.h>

int numeroSecreto, palpite;
int tentativa = 0;
int acertou = 0;

int main() {
    
    printf("Jogador 1: Digite um número entre 1 e 10: ");
    scanf("%d", &numeroSecreto);
    
    printf("\nJogador 2: Você tem 4 tentativas para adivinhar!\n");
    
    for (tentativa = 1; tentativa <= 4; tentativa++) {
        printf("Tentativa %d: Digite seu palpite: ", tentativa);
        scanf("%d", &palpite);
        
        if (palpite == numeroSecreto) {
            printf("Você acertou na tentativa %d!\n", tentativa);
            acertou = 1;
            break;
        } else if (palpite < numeroSecreto) {
            printf("O número é maior.\n");
        } else {
            printf("O número é menor.\n");
        }
    }
    
    if (!acertou) {
        printf("Você não acertou! O número era %d.\n", numeroSecreto);
    }
    
    return 0;
}
