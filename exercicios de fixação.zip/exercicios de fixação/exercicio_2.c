#include <stdio.h>

int i;

int main() {
    for (i = -5; i < 0; i++) {
        printf("%d\n",i);
    }
}