#include <stdio.h>

int main() {
    int anos;
    int cigarrosPorDia;
    double precoCarteira;
    double totalGasto;
    int diasTotais;
    int carteirasPorDia;
    
    printf("Quantos anos você fuma? ");
    scanf("%d", &anos);
    printf("Quantos cigarros fuma por dia? ");
    scanf("%d", &cigarrosPorDia);
    printf("Preço de uma carteira de cigarros: R$ ");
    scanf("%lf", &precoCarteira);
    
    diasTotais = anos * 365;
    int cigarrosTotais = cigarrosPorDia * diasTotais;
    int cigarrosPorCarteira = 20;
    int carteirasTotais = cigarrosTotais / cigarrosPorCarteira;
    if (cigarrosTotais % cigarrosPorCarteira != 0) {
        carteirasTotais++;
    }
    
    totalGasto = carteirasTotais * precoCarteira;
    
    printf("Total gasto em cigarros: R$ %.2f\n", totalGasto);
    
    return 0;
}
