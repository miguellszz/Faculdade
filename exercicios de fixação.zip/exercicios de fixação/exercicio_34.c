#include <stdio.h>
#include <math.h>

int main() {
    double raio;
    double volume;
    
    printf("Digite o raio da esfera (m): ");
    scanf("%lf", &raio);
    
    volume = (4.0 / 3.0) * M_PI * raio * raio * raio;
    
    printf("Volume da esfera: %.2f m³\n", volume);
    
    return 0;
}
