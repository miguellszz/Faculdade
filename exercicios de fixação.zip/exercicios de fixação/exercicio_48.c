#include <stdio.h>

double h,r;
int n;
double distanciaTotal;
double alturaAtual;

int main() {
    
    printf("Digite a altura inicial (H): ");
    scanf("%lf", &h);
    printf("Digite o coeficiente de salto (R): ");
    scanf("%lf", &r);
    printf("Digite o número de saltos (N): ");
    scanf("%d", &n);
    
    distanciaTotal = h;
    alturaAtual = h;
    
    for (int i = 1; i <= n; i++) {
        alturaAtual = alturaAtual * r;
        distanciaTotal += 2 * alturaAtual;
    }
    
    printf("Distância percorrida até o %dº salto: %.2f\n", n, distanciaTotal);
    printf("Altura do %dº salto: %.2f\n", n, alturaAtual);
    
    return 0;
}
