#include <stdio.h>
#include <stdlib.h>

float nota1,nota2,nota3,nota3, nota4,media;

int main() {
    printf("Digite as suas notas nao ordem, ex: 6.7;  8.9; 5.5; 6.7: ");
    scanf("%f %f %f %f", &nota1,&nota2, &nota3, &nota4);

    media = (nota1 + nota2 + nota3 + nota4) / 4;
    printf("Sua media é: %.1f", media);
}