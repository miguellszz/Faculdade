#include <stdio.h>
#include <stdlib.h>

int i ,numero,tabuada;

int main() {
    printf("Digite o numero que voce deseja obter a tabuada: ");
    scanf("%d", &numero);

    for (i = 0; i<=10 ; i++) {
        tabuada = i * numero;
        printf("\nA tabuade de %d é %d x %d = %d ", numero, numero, i, tabuada);
    }

}