#include <stdio.h>
#include <stdlib.h>

int i;

int main() {
    for (i = 1; i <= 5; i++) {
        printf("%d\n", i);
    }
}