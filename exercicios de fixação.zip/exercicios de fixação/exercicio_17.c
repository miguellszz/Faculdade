#include <stdio.h>
#include <math.h>
#include <stdlib.h>

double cateto1,cateto2,hipotenusa;

int main() {
    printf("Informe os valores dos catetos: ");
    scanf("%lf %lf", &cateto1, &cateto2);

    hipotenusa = sqrt(pow(cateto1, 2) + pow(cateto2, 2));

    printf("O valor da hipotenusa é : %.2lf", hipotenusa);
}